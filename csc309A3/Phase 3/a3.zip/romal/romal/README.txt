in mongo shell, wipe all data with:
db.tagcollection.remove({})
db.recipecollection.remove({})
db.ratingcollection.remove({})
db.commentcollection.remove({})
must manually remove images afterward

create new admin account (replace 2nd column with account details, except for the "admin" field):
db.usercollection.insert({
"username" : "username",
"email" : "email",
"firstname" : "firstname",
"lastname" : "lastname",
"password" : "testadmin",
"admin" : "admin"})

