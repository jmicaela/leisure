var express = require('express');
var router = express.Router();
//cookie initialization
var session = require('client-sessions');
router.use(session({
  cookieName: 'session',
  secret: 'random_string_goes_here',
  duration: 30 * 60 * 1000,
  activeDuration: 5 * 60 * 1000,
}));
//multer initialization
var multer = require('multer');
var fs = require('fs');
var util = require("util");

//GENERAL NOTES
/*
* in all functions req.session.user and req.session.admin are accessed, this allows the jade files to see which user session to display
* if req.session.admin exists (set during the login, which checks the database if the user is an admin), the .jade files will display extra features
* db collections are 'usercollection' 'recipecollection' 'tagcollection' 'commentcollection' 'ratingcollection'
* 
*
*
*/



/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Recipe Book' ,
  		"userlog" : req.session.user,
		"admin" : req.session.admin
		});
});





router.get('/register', function(req, res) {
	res.render('register');
});

//called by layout.jade, renders recipeform.jade which allows user to create new recipe
router.post('/recipeform', function(req, res) {
	var userlog = req.session.user;
	res.render('recipeform', {
		"userlog" : userlog,
		"admin" : req.session.admin
	});
});

//takes input of title and author of a recipe from a form and outputs the recipe searched
router.post('/viewrecipe', function(req, res) {
	var userlog = req.session.user;
	var db = req.db;
	var title = req.body.title;
	var author = req.body.author;
	var reccollection = db.get('recipecollection');
	var comcollection = db.get('commentcollection');
	var tagcollection = db.get('tagcollection');
	var tagarray;
	//find the recipe, its comments, and its tags, and export them to viewrecipe.jade
	reccollection.find({author:author, title:title},{},function(e,docs2){
		comcollection.find({author:author, title:title},{},function(e,docs){
			tagcollection.find({author:author, title:title},{},function(e, tags){
				res.render('viewrecipe', {
				"author" : docs2[0].author,
				"title" : docs2[0].title,
				"image" : docs2[0].image,
				"ingredients" : docs2[0].ingredients,
				"instructions" : docs2[0].instructions,
				"tags" : tags,
				"rating" : docs2[0].rating,
				"userlog" : userlog,
				"admin" : req.session.admin,
				"comments" : docs
				});
			});
		});
	});
});

//take in a tag as input from form, and outputs an array of all recipes with that tag
router.post('/searchresults', function(req, res) {
	var userlog = req.session.user;
	var tempsearch = req.body.search
	var search = tempsearch.toLowerCase();
	var db = req.db;
	var tagcollection = db.get('tagcollection');
	var recipecollection = db.get('recipecollection');
	var recipearray;
	var imgs = [];
	var i;
	tagcollection.find({tag : search},{},function(e,docs){
		for (i=0; i<docs.length; i++){
			recipecollection.find({title : docs[i].title, author : docs[i].author},{},function(e,docs2){
					
			});
		}
		
		res.render('searchresults', {
			"userlog" : userlog,
			"admin" : req.session.admin,
			"recipe" : docs
		});
	});
});

//renders the settings.jade 
router.post('/settings', function(req, res) {
	var userlog = req.session.user;
	res.render('settings',{
		"userlog" : userlog,
		"admin" : req.session.admin
	});
});

//takes in a new password from a form input in settings.jade and changes the current user's password
router.post('/accsettings', function(req, res){
	var userlog = req.session.user;
	var newpass = req.body.password;
	var db = req.db;
	var usercollection = db.get('usercollection');
	// find user based on the session's user data, then sets the password to a new password
	usercollection.update(
		{
			"username" : userlog
		},
		{
			$set :
			{
				"password" : newpass
			}
		}
	);
	var regerror = "Password Changed";
	//rerenders the settings.jade page and displays that the password was changed
	res.render('settings',{
					"regerror" : regerror,
					"admin" : req.session.admin,
					"userlog" : userlog
	});
});

//finds all comments and all recipes submitted by the logged in user, and renders their profile
router.post('/viewprofile', function(req, res) {
	var userlog = req.session.user;
	var db = req.db;
	var recipecollection = db.get('recipecollection');
	var commentcollection = db.get('commentcollection');
	var usercollection = db.get('usercollection');
	usercollection.find({username:userlog},{},function(e,user){
		recipecollection.find({author:userlog},{},function(e,docs){
			commentcollection.find({author:userlog},{},function(e,docs2){
				res.render('viewprofile',{
					"myrecipes" : docs,
					"mycomments" : docs2,
					"admin" : req.session.admin,
					"userlog" : userlog,
					"profile" : userlog,
					"user" : user[0]
				});
			});
		});
	});
});

//finds all comments and all recipes submitted by searched user, and renders their profile
router.post('/viewprofilerecipe', function(req, res) {
	var userlog = req.session.user;
	var author = req.body.author;
	var db = req.db;
	var recipecollection = db.get('recipecollection');
	var commentcollection = db.get('commentcollection');
	var usercollection = db.get('usercollection');
	usercollection.find({username:author},{},function(e,user){
		recipecollection.find({author:author},{},function(e,docs){
			commentcollection.find({author:author},{},function(e,docs2){
				res.render('viewprofile',{
					"myrecipes" : docs,
					"mycomments" : docs2,
					"admin" : req.session.admin,
					"userlog" : userlog,
					"profile" : author,
					"user" : user[0]
				});
			});
		});
	});
});

//removes the recipe from recipecollection, and all comments/tags associated with the recipe
router.post('/deleterecipe', function(req, res){
	var userlog = req.session.user;
	var author = req.body.author;
	var title = req.body.title;
	var db = req.db;
	var recipecollection = db.get('recipecollection');
	var commentcollection = db.get('commentcollection');
	var tagcollection = db.get('tagcollection');
	
	recipecollection.remove({
		"author" : author,
		"title" : title		
	});
	tagcollection.remove({
		"author" : author,
		"title" : title		
	});
	commentcollection.remove({
		"author" : author,
		"title" : title		
	});
	// sends user back to home page with a success message
	res.render('index', {
            "userlog" : req.session.user,
			"admin" : req.session.admin,
			"message" : "Recipe "+title +" Deleted"
    });
});

//while viewing a recipe on viewrecipe.jade, if the logged in user is the same as a comment's user (or if the user is an admin), there will be 
//a delete button next to that comment (all comments for admin), calling this function
router.post('/deletecomment', function(req, res){
	var userlog = req.session.user;
	var author = req.body.author;
	var title = req.body.title;
	var commenter = req.body.commenter;
	var comment = req.body.comment;
	var time = req.body.time;
	var db = req.db;
	var commentcollection = db.get('commentcollection');
	var reccollection = db.get('recipecollection');
	var tagcollection = db.get('tagcollection');
	//remove the comment from commentcollection
	commentcollection.remove({
		"author" : author,
		"title" : title,
		"commenter" : commenter,
		"comment" : comment
	});
	// rerender the recipe the user was currently browsing
		reccollection.find({author:author, title:title},{},function(e,docs2){
			tagcollection.find({author:author, title:title},{},function(e, tags){
					commentcollection.find({author:author, title:title},{},function(e,docs){
						res.render('viewrecipe', {
						"author" : docs2[0].author,
						"title" : docs2[0].title,
						"image" : docs2[0].image,
						"ingredients" : docs2[0].ingredients,
						"instructions" : docs2[0].instructions,
						"rating" : docs2[0].rating,
						"admin" : req.session.admin,
						"userlog" : userlog,
						"comments" : docs,
						"tags" : tags
						});
					});
			});
		});
});

//if user is logged in, they can pick a value from 1-5 and rate a recipe from viewrecipe.jade
//a user rate a recipe multiple times but their old rating is overwritten 
router.post('/raterecipe', function(req, res) {
	var userlog = req.session.user;
	var db = req.db;
	var star = parseInt(req.body.star);
	var title = req.body.title;
	var author = req.body.author;
	var ratingcollection = db.get('ratingcollection');
	var reccollection = db.get('recipecollection');
	var comcollection = db.get('commentcollection');
	var tagcollection = db.get('tagcollection');
	var ratingsum = 0;
	var ratingtotal = 0;
	var oldrating = 0;
	var update = 1;
	ratingcollection.find({rater:userlog, title:title, author:author},{},function(e,ratedocs){
		if (ratedocs.length){
			//database already shows this user has rated this recipe, only update
			oldrating = ratedocs[0].rating;
			ratingcollection.update(
			{
				"author" : author,
				"title" : title,
				"rater" : userlog
			},
			{
				$set :
				{
					"rating" : star
				}
			});
			update = 0;
		}
		else{
			//logged in user has never rated this recipe before, add new rating
			ratingcollection.insert({
				"author" : author,
				"title" : title,
				"rater" : userlog,
				"rating" : star			
			});
			reccollection.update(
			{
				"author" : author,
				"title" : title
			}, 
			{
				$inc :
				{
					"totalrating" : 1
				}
			});
		}
		//overall rating for the recipe is updated, this is done by multplying the old rating by the total number of rates, adding the new rating, and dividing by the new total number of rates
		//if the rating is updated and not a new one, we subtract the old rating the user made, add the new one, and do not increase the total number of rates
		var temprating = 0 ;
		reccollection.find({title:title, author:author},{},function(e,temp){
			
			temprating = ((temp[0].rating * ((temp[0].totalrating)-update)) + star - oldrating)/(temp[0].totalrating) ;
			
			reccollection.update(
			{
				"author" : author,
				"title" : title
			}, 
			{
				$set :
				{
					"rating" : temprating
				}
			});
			//re render the recipe page the user just rated
		reccollection.find({author:author, title:title},{},function(e,docs2){
			tagcollection.find({author:author, title:title},{},function(e, tags){
					comcollection.find({author:author, title:title},{},function(e,docs){
						res.render('viewrecipe', {
						"author" : docs2[0].author,
						"title" : docs2[0].title,
						"image" : docs2[0].image,
						"ingredients" : docs2[0].ingredients,
						"instructions" : docs2[0].instructions,
						"rating" : docs2[0].rating,
						"admin" : req.session.admin,
						"userlog" : userlog,
						"comments" : docs,
						"tags" : tags
						});
					});
			});
		});

		});

		
	});


});


//add a new recipe after filling out recipeform.jade
router.post('/addrecipe', function(req, res) {
	var userlog = req.session.user;
    var db = req.db;
	var username = userlog;
	var title = req.body.Title;
	var ingredients = req.body.Ingredients;
	var instructions = req.body.Instructions;
	var tags = req.body.Tags;
	var tagarray = tags.split(" ");
	var image;
	//uses multer api to create a copy of the image server side, which assigns it a unique name
	if(req.files) {
		console.log(util.inspect(req.files));
		image = req.files.image.name;
		if(req.files.image.size === 0) {
			//default image here
			image = 'noPrev.png';
		}
		fs.exists(req.files.image.path, function(exists) {
			if(exists) {
				image = req.files.image.name;
				// do resize
				
			}
			else {
				//error uploading
				image = 'noPrev.jpg';
				//use default image
			}
		});
	}
    var collection = db.get('recipecollection');
	var tagcollection = db.get('tagcollection');

	//checks if the recipe name has already been submitted (different users can submit the same recipe name but one user cannot have multiple recipes of same name)
	collection.find({author:userlog, title:title},{},function(e,docs){
		if (!docs.length){
			// UNIQEUE RECIPE NAME, save into db
			collection.insert({
				"author" : userlog,
				"title" : title,
				"image" : "images/" + image,
				"ingredients" : ingredients,
				"instructions" : instructions,
				"rating" : 0,
				"totalrating" : 0
			});
			for (var i in tagarray){
				//saves each individual tag into the tag db so we can search by tag
				tagcollection.insert({
					"author" : userlog,
					"title" : title,
					"tag" : tagarray[i].toLowerCase()
				});
			}
			//render the recipe page that was just created
			res.render('viewrecipe', {
				"author" : userlog,
				"title" : title,
				"image" : "images/" + image,
				"ingredients" : ingredients,
				"instructions" : instructions,
				"rating" : 0,
				"userlog" : userlog,
				"admin" : req.session.admin,
				"tagarray" : tagarray
			});
		}
		else{
			// USER ALREADY SUBMITTED RECIPE
			//re render the recipeform page with an error message
				res.render('recipeform', {
					"userlog" : userlog,
					"admin" : req.session.admin,
					"recerror" : 'You have already submitted a recipe with title "'+title+'"'
				});
		}

	});
});

//if a user is logged in and viewing a recipe on viewrecipe.jade, they will have the option to add comment, calling this function
router.post('/addcomment', function(req, res) {
	var db = req.db;
	var comcollection = db.get('commentcollection');
	var reccollection = db.get('recipecollection');
	var tagcollection = db.get('tagcollection');
	var userlog = req.session.user;
	var userName = req.body.username;
	var title = req.body.title;
	var author = req.body.author;
	var comment = req.body.comment
	var time = Date.now();
	
	//save the user's comment into the db
	comcollection.insert({
		"author" : author,
		"title" : title,
		"commenter" : userlog,
		"comment" : comment,
		"time" : time,
		"rating" : 0
	});
	//re render the recipe page they were viewing
	reccollection.find({author:author, title:title},{},function(e,docs2){
		tagcollection.find({author:author, title:title},{},function(e, tags){
				comcollection.find({author:author, title:title},{},function(e,docs){
					res.render('viewrecipe', {
					"author" : docs2[0].author,
					"title" : docs2[0].title,
					"image" : docs2[0].image,
					"ingredients" : docs2[0].ingredients,
					"instructions" : docs2[0].instructions,
					"rating" : docs2[0].rating,
					"userlog" : userlog,
					"admin" : req.session.admin,
					"comments" : docs,
					"tags" : tags
					});
				});
		});
	});


});

//newuser.jade has a form allowing a new account to be registered
router.post('/adduser', function(req, res) {

    // Set our internal DB variable
    var db = req.db;

    // Get our form values. These rely on the "name" attributes
    var userName = req.body.username;
    var userEmail = req.body.useremail;
	var firstName = req.body.firstname;
	var lastName = req.body.lastname;
	var password = req.body.password;
	
	

    var collection = db.get('usercollection');
	
	//checks if the email has already been registered
	collection.find({email:userEmail},{},function(e,docs){
		if (!docs.length){
			//checks if the username has already been registered
			collection.find({username:userName},{},function(e,docs){
				if (!docs.length){
					    // Submit to the DB
					collection.insert({
						"username" : userName,
						"email" : userEmail,
						"firstname" : firstName,
						"lastname" : lastName,
						"password" : password,
						"admin" : "basic"
					}, function (err, doc) {
						if (err) {
							// SERVER SIDE ERROR
							res.send("There was a problem adding the information to the database.");
						}
						else {
						// SUCCESSFUL REGISTRATION
						// render the new user's profile
							collection.find({username:userName},{},function(e,users){
										req.session.user = userName;
										res.render('viewprofile', {
										"admin" : req.session.admin,
										"userlog" : userName,
										"profile" : userName,
										"user" : users[0]
									});
							});
						}
					});
				}
				else{
					//USERNAME TAKEN
					//render the register page again with an error message
					res.render('register', {
						regerror : 'Username "'+userName+'" taken'
					});
				}
			});

		}
		else{
			//EMAIL TAKEN 
			//render the register page again with an error message
				res.render('register', {
					regerror : 'Email "'+userEmail+'" taken'
				});
		}

	});
});

//at the top of the page, layout.jade has a log out button which calls this function, deleting the user's session
router.post('/logout', function(req,res){
  req.session.reset();
  res.render('index', {
	  "logerror" : "Logged out!"
  });
});

//at the top of the page, layout.jade has a email/password form which calls this function
router.post('/login', function(req, res) {
	var userEmail = req.body.useremail;
	var pass = req.body.password;
    var db = req.db;
    var collection = db.get('usercollection');
	//check if the email/password combination is in the database, each email is unique
    collection.find({email:userEmail, password:pass},{},function(e,docs){
		if (docs.length){
			// SUCCCESS
			// create new user session based on the username, check if the db has them as an admin
			// some pages checks if the admin variable exists to display extra admin features
			req.session.user = docs[0].username;
			if (docs[0].admin == "admin"){
				req.session.admin = "y";
			}
			else{
				req.session.admin = null;
			}
			//render home page 
		res.render('index', {
            "userlog" : req.session.user,
			"admin" : req.session.admin
        });

		}
		else{
			// render homepage with error message
				res.render('index', {
					"logerror" : 'Email or password incorrect'
				});
		}

	});
	
});



module.exports = router;
